// ═══════════════════════════════════════════════════════════
//  MITTI AI  —  Express Server  v4.0
//  Production-ready with security, logging, rate limiting
// ═══════════════════════════════════════════════════════════

require("dotenv").config();
const express    = require("express");
const cors       = require("cors");
const helmet     = require("helmet");
const morgan     = require("morgan");
const compression = require("compression");
const rateLimit  = require("express-rate-limit");

const logger     = require("./config/logger");
const { connectDB } = require("./config/database");

// ── Routes ────────────────────────────────────────────────
const authRoutes    = require("./routes/auth");
const userRoutes    = require("./routes/user");
const aiRoutes      = require("./routes/ai");
const soilRoutes    = require("./routes/soil");
const cropRoutes    = require("./routes/crop");
const mandiRoutes   = require("./routes/mandi");
const marketRoutes  = require("./routes/market");
const schemeRoutes  = require("./routes/schemes");
const notifRoutes   = require("./routes/notifications");
const adminRoutes   = require("./routes/admin");
const weatherRoutes = require("./routes/weather");

const app  = express();
const PORT = process.env.PORT || 3001;

// ── Security Middleware ───────────────────────────────────
app.use(helmet());
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(",") || ["http://localhost:3000"],
  credentials: true,
}));

// ── Rate Limiting ──────────────────────────────────────────
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,   // 15 minutes
  max: 200,
  message: { error: "बहुत अधिक requests। कृपया कुछ देर बाद कोशिश करें।" },
});
const authLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,   // 10 minutes
  max: 10,
  message: { error: "OTP limit exceeded। 10 मिनट बाद कोशिश करें।" },
});

app.use(globalLimiter);
app.use(compression());
app.use(express.json({ limit: "10mb" }));  // for image uploads
app.use(express.urlencoded({ extended: true }));
app.use(morgan("combined", { stream: { write: (msg) => logger.info(msg.trim()) } }));

// ── Health Check ──────────────────────────────────────────
app.get("/health", (req, res) => res.json({
  status: "✅ MITTI AI Backend Running",
  version: "4.0.0",
  timestamp: new Date().toISOString(),
  env: process.env.NODE_ENV,
}));

// ── API Routes ────────────────────────────────────────────
app.use("/api/auth",          authLimiter, authRoutes);
app.use("/api/user",          userRoutes);
app.use("/api/ai",            aiRoutes);
app.use("/api/soil",          soilRoutes);
app.use("/api/crop",          cropRoutes);
app.use("/api/mandi",         mandiRoutes);
app.use("/api/market",        marketRoutes);
app.use("/api/schemes",       schemeRoutes);
app.use("/api/notifications", notifRoutes);
app.use("/api/admin",         adminRoutes);
app.use("/api/weather",       weatherRoutes);

// ── 404 Handler ───────────────────────────────────────────
app.use("*", (req, res) => res.status(404).json({
  error: "Route नहीं मिला",
  path: req.originalUrl,
}));

// ── Global Error Handler ──────────────────────────────────
app.use((err, req, res, next) => {
  logger.error(`${err.status || 500} — ${err.message} — ${req.originalUrl}`);
  res.status(err.status || 500).json({
    error: process.env.NODE_ENV === "production"
      ? "सर्वर में समस्या। कृपया बाद में कोशिश करें।"
      : err.message,
  });
});

// ── Start Server ──────────────────────────────────────────
async function start() {
  await connectDB();
  app.listen(PORT, () => {
    logger.info(`🌱 MITTI AI Backend started on port ${PORT}`);
    logger.info(`📡 API: http://localhost:${PORT}/health`);
  });
}

start().catch((err) => {
  logger.error("Failed to start server:", err);
  process.exit(1);
});

module.exports = app;
