// ── DB Seed: Crops + Govt Schemes ────────────────────────
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding MITTI AI database...');

  // Crops
  const crops = [
    { name:'wheat',    nameHindi:'गेहूं',  nameBhojpuri:'गोहुँम',  season:'Rabi',   duration:120, yieldPerAcre:20, minTemp:10, maxTemp:25, waterReq:'Medium',  soilType:'Loamy',  fertilizerNPK:'120:60:40', commonDiseases:['rust','smut'],         marketPrice:2200 },
    { name:'rice',     nameHindi:'धान',    nameBhojpuri:'धान',      season:'Kharif', duration:150, yieldPerAcre:25, minTemp:20, maxTemp:37, waterReq:'High',    soilType:'Clay',   fertilizerNPK:'100:50:50', commonDiseases:['blast','blight'],      marketPrice:1900 },
    { name:'maize',    nameHindi:'मक्का',  nameBhojpuri:'मक्का',   season:'Kharif', duration:90,  yieldPerAcre:30, minTemp:18, maxTemp:32, waterReq:'Medium',  soilType:'Sandy',  fertilizerNPK:'120:60:40', commonDiseases:['borer','rust'],         marketPrice:1600 },
    { name:'potato',   nameHindi:'आलू',    nameBhojpuri:'अलुआ',    season:'Rabi',   duration:90,  yieldPerAcre:100,minTemp:15, maxTemp:25, waterReq:'Medium',  soilType:'Sandy',  fertilizerNPK:'180:120:100',commonDiseases:['blight','wilt'],        marketPrice:1200 },
    { name:'mustard',  nameHindi:'सरसों',  nameBhojpuri:'सरसों',   season:'Rabi',   duration:120, yieldPerAcre:8,  minTemp:10, maxTemp:25, waterReq:'Low',     soilType:'Loamy',  fertilizerNPK:'80:40:40',  commonDiseases:['aphid','rot'],           marketPrice:5100 },
    { name:'sugarcane',nameHindi:'गन्ना',  nameBhojpuri:'ऊख',      season:'Annual', duration:365, yieldPerAcre:400,minTemp:20, maxTemp:40, waterReq:'Very High',soilType:'Loamy',  fertilizerNPK:'250:80:120', commonDiseases:['smut','wilt'],         marketPrice:350  },
    { name:'lentil',   nameHindi:'मसूर',   nameBhojpuri:'मसुर',    season:'Rabi',   duration:110, yieldPerAcre:6,  minTemp:5,  maxTemp:25, waterReq:'Low',     soilType:'Loamy',  fertilizerNPK:'20:60:20',  commonDiseases:['wilt','rust'],           marketPrice:5500 },
    { name:'tomato',   nameHindi:'टमाटर',  nameBhojpuri:'टमाटर',   season:'Annual', duration:90,  yieldPerAcre:120,minTemp:15, maxTemp:30, waterReq:'Medium',  soilType:'Sandy',  fertilizerNPK:'120:60:60', commonDiseases:['blight','mosaic'],      marketPrice:2800 },
  ];

  for (const c of crops) {
    await prisma.crop.upsert({ where: { name: c.name }, update: c, create: c });
  }
  console.log(`✅ ${crops.length} crops seeded`);

  // Govt Schemes
  const schemes = [
    { name:'PM-KISAN',          nameHindi:'पीएम किसान सम्मान निधि', type:'central', benefit:'₹6,000/year in 3 installments', maxAmount:6000,  eligibility:'Small/marginal farmers with <2 ha land', documents:['Aadhaar','Land records','Bank account'], helpline:'155261',          applyUrl:'https://pmkisan.gov.in' },
    { name:'PMFBY',             nameHindi:'प्रधानमंत्री फसल बीमा',  type:'central', benefit:'Up to 80% crop loss compensation',maxAmount:null,  eligibility:'All farmers growing notified crops',       documents:['Aadhaar','Land records','Bank account','Sowing certificate'], helpline:'14447', applyUrl:'https://pmfby.gov.in' },
    { name:'KCC',               nameHindi:'किसान क्रेडिट कार्ड',    type:'bank',    benefit:'Credit up to ₹3 lakh at 4% interest',maxAmount:300000, eligibility:'All farmers', documents:['Aadhaar','PAN','Land records'], helpline:'1800-180-1111', applyUrl:'https://www.nabard.org' },
    { name:'Bihar Solar Pump',  nameHindi:'बिहार सोलर पंप योजना',  type:'state',   benefit:'90% subsidy on solar pump',      maxAmount:null,  eligibility:'Bihar farmers', documents:['Aadhaar','Land records','Electricity bill'], helpline:'0612-2233555', applyUrl:'https://dbtagriculture.bihar.gov.in' },
  ];

  for (const s of schemes) {
    await prisma.govtScheme.upsert({ where: { name: s.name }, update: s, create: s }).catch(() => prisma.govtScheme.create({ data: s }));
  }
  console.log(`✅ ${schemes.length} govt schemes seeded`);
  console.log('\n🎉 Database seeded successfully!\n');
}

main().catch(e => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
